## صفحه ها وب سایت 
Go : [HOME](https://raminrodbri.github.io/)
## تنظیمات 
+ `raminrodbri.github.io`

   + [EDIT CODE - ویرایش کد](https://github.com/raminrodbri/raminrodbri.github.io)
   + [ISSUES - مسائل](https://github.com/raminrodbri/raminrodbri.github.io/issues)
   + [PULL REQUESTS - درخواست های کشش](https://github.com/raminrodbri/raminrodbri.github.io/pulls)
   + [ACTIONS - اقدامات](https://github.com/raminrodbri/raminrodbri.github.io/actions)
   + [PROJECTS - پروژه ها](https://github.com/raminrodbri/raminrodbri.github.io/projects?type=beta)
   + [WIKI - ویکی ](https://github.com/raminrodbri/raminrodbri.github.io/wiki)
   + [SECURITY - امنیت](https://github.com/raminrodbri/raminrodbri.github.io/security)
   + [INSIGHTS - بینش](https://github.com/raminrodbri/raminrodbri.github.io/pulse)
   + [EDIT SETTINGS - ویرایش تنظیمات](https://github.com/raminrodbri/raminrodbri.github.io/edit/)
## ایجاد صفحه / پوشه
* [آپلود]()
* [نوشتن]() 




***
* `برای ایجاد پوشه از`   `/`  `استفاده کنید`


