<script type="text/javascript">
 var myArray = [1, 5, 8, 2, 3, 0, 2, 9, 11];
 var i = 0;
 var j = 0;
 for (i = 0; i < myArray.length ; ++i) {
  for (j = 0; j < myArray.length; ++j) {
   if (myArray[i] <myArray[j]) {
    var tmp = myArray[i];
    myArray[i] = myArray[j];
    myArray[j] = tmp;
   }
  }
 }

 for (i = 0; i < myArray.length; ++i) {
  document.write(myArray[i] + " ");
 }
</script>
